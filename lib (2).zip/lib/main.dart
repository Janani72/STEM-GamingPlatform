import 'package:flutter/material.dart';
import 'games/bubbleShooter.dart';
import 'games/engineering.dart';
import 'games/kiteQuizz.dart';
import 'games/tech.dart';
import 'theme/app_theme.dart';
import 'pages/landingPage.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GamifiedLearningApp());
}

class GamifiedLearningApp extends StatelessWidget {
  const GamifiedLearningApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "STEM Gamified Learning",
      theme: AppTheme.lightTheme,
      debugShowCheckedModeBanner: false,
      home:  HeroPage(),
    );
  }
}
