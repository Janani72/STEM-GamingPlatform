import 'package:flutter/material.dart';
import 'package:testvapt/pages/teacher.dart';
import 'activityPage.dart';
import 'landingPage.dart';
import 'leaderboardPage.dart';
import 'package:shared_preferences/shared_preferences.dart';


class StemPage extends StatelessWidget {
  final String username;
  const StemPage({super.key, required this.username});

  @override
  Widget build(BuildContext context) {
    final subjects = [
      {"name": "Science", "image": "assets/images/science.png"},
      {"name": "Math", "image": "assets/images/math.png"},
      {"name": "Technology", "image": "assets/images/technology.png"},
      {"name": "Engineering", "image": "assets/images/engineering.png"},
    ];

    // Use consistent soft purple gradient pattern like LoginPage
    final cardGradientColors = [
      [Color(0xFF7E57C2), Color(0xFF4B3F72)],
      [Color(0xFF7E57C2), Color(0xFF4B3F72)],
      [Color(0xFF7E57C2), Color(0xFF4B3F72)],
      [Color(0xFF7E57C2), Color(0xFF4B3F72)],
    ];

    Future<void> saveUsername(String username) async {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('username', username);
    }

    return Scaffold(
      appBar: AppBar(
        title: username != '' ? Text(
          "Hello Genius, $username! 🚀",
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold ,color: Colors.white
          ) ,
        ) :  null,
        backgroundColor: const Color(0xFF4B3F72),
        elevation: 4,
        iconTheme: const IconThemeData(color: Colors.white), // <-- makes default arrow white
        actions: [
          IconButton(
            icon: const Icon(Icons.logout,color: Colors.white),
            tooltip: "Logout",
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (_) => const HeroPage()),
                    (route) => false,
              );
            },
          )
        ],
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF5F5F5), Color(0xFFEDE7F6)], // Soft pastel
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            itemCount: subjects.length,
            itemBuilder: (context, index) {
              final subject = subjects[index];
              return GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          ActivityPage(subject: subject["name"]!),
                    ),
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: cardGradientColors[index],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black26,
                        blurRadius: 6,
                        offset: Offset(2, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(subject["image"]!, width: 60, height: 60),
                      const SizedBox(height: 12),
                      Text(
                        subject["name"]!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 18,
                          shadows: [
                            Shadow(
                              color: Colors.black26,
                              blurRadius: 2,
                              offset: Offset(1, 1),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: const Color(0xFF4B3F72),
        unselectedItemColor: Colors.grey,
        elevation: 8,
        type: BottomNavigationBarType.fixed,
        currentIndex: 0, // default selected index
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Teachers Dashboard",
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StemPage(username: '',),
              ),
            );
          } else if (index == 1) {
            // Navigate to Teachers Dashboard
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TeachersDashboardPage(),
              ),
            );
          }
        },
      ),
    );
  }
}
