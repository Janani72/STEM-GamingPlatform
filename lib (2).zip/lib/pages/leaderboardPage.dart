import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:testvapt/pages/teacher.dart';
import 'dashboardPage.dart';

class DashboardPage extends StatefulWidget {
  final String? subject;
  final String? activity;

  const DashboardPage({super.key, this.subject, this.activity});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  String username = "Guest";
  int quizScore = 0;
  int puzzlesSolved = 0;
  String lastActivity = "None";

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      username = prefs.getString('username') ?? "Guest";
      quizScore = prefs.getInt("${widget.subject ?? 'Science'}_score") ?? 0;
      puzzlesSolved = prefs.getInt("${widget.subject ?? 'Science'}_puzzles") ?? 0;
      lastActivity = prefs.getString("last_subject") ?? "None";
    });
  }

  Widget _buildStatCard(String title, String value, IconData icon, List<Color> colors) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: colors, begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: colors.last.withOpacity(0.4), blurRadius: 8, offset: const Offset(2, 4))],
      ),
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 40, color: Colors.white),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, fontSize: 14)),
          const SizedBox(height: 6),
          Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDE7F6),
      appBar: AppBar(
        backgroundColor: const Color(0xFF4B3F72),
        elevation: 4,
        title: const Text("Scoreboard", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Welcome, $username! 👋", style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF4B3F72))),
            const SizedBox(height: 8),
            Text("Your progress in ${widget.subject ?? 'Science'} → ${widget.activity ?? 'Quiz'}", style: const TextStyle(fontSize: 16, color: Colors.black87)),
            const SizedBox(height: 24),
            const Text("Your Achievements", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF4B3F72))),
            const SizedBox(height: 16),
            Expanded(
              child: GridView(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 16, crossAxisSpacing: 16, childAspectRatio: 1),
                children: [
                  _buildStatCard("Quizzes Completed", "$quizScore", Icons.quiz, [Color(0xFF7E57C2), Color(0xFF4B3F72)]),
                  _buildStatCard("Puzzles Solved", "$puzzlesSolved", Icons.extension, [Color(0xFF26C6DA), Color(0xFF00ACC1)]),
                  _buildStatCard("Best Score", "$quizScore%", Icons.emoji_events, [Color(0xFFFFB74D), Color(0xFFFF8A65)]),
                  _buildStatCard("Last Activity", lastActivity, Icons.history, [Color(0xFF81C784), Color(0xFF4CAF50)]),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: const Color(0xFF4B3F72),
        unselectedItemColor: Colors.grey,
        elevation: 8,
        type: BottomNavigationBarType.fixed,
        currentIndex: 0, // default selected index
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Teachers Dashboard",
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StemPage(username: '',),
              ),
            );
          } else if (index == 1) {
            // Navigate to Teachers Dashboard
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TeachersDashboardPage(),
              ),
            );
          }
        },
      ),
    );
  }
}
