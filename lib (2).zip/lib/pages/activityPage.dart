import 'package:flutter/material.dart';
import 'package:testvapt/pages/teacher.dart';

import '../games/bubbleShooter.dart';
import '../games/engineering.dart';
import '../games/kiteQuizz.dart';
import '../games/tech.dart';
import 'dashboardPage.dart';

class ActivityPage extends StatelessWidget {
  final String subject;
  const ActivityPage({super.key, required this.subject});

  @override
  Widget build(BuildContext context) {
    // Activities based on subject
    final activities = [
      if (subject == 'Science') "Quiz - Kite Game",
      if (subject == 'Math') "Math - Bubble Click",
      if (subject == 'Technology') "Tech - Memory Game",
      if (subject == 'Engineering') "Engineering - Treasure Hunt"
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Activities - $subject",
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: const Color(0xFF4B3F72),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 4,
        centerTitle: true,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF5F5F5), Color(0xFFEDE7F6)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: activities.length,
          itemBuilder: (context, index) {
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              elevation: 6,
              margin: const EdgeInsets.symmetric(vertical: 12),
              shadowColor: Colors.deepPurple.withOpacity(0.2),
              child: ListTile(
                contentPadding:
                const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                title: Text(
                  activities[index],
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                    color: Color(0xFF4B3F72),
                  ),
                ),
                trailing: const Icon(Icons.arrow_forward,
                    color: Color(0xFF4B3F72)),
                onTap: () {
                  switch (activities[index]) {
                    case "Quiz - Kite Game":
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => KiteQuizHome()), // Your Kite Game
                      );
                      break;
                    case "Math - Bubble Click":
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => BubbleGameScreen()), // Bubble Game
                      );
                      break;
                    case "Engineering - Treasure Hunt":
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => TreasureHuntScreen()), // Tech Game
                      );
                      break;
                    default:
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => MemoryGameScreen(
                          ),
                        ),
                      );
                  }
                },
              ),
            );
          },
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.white,
        selectedItemColor: const Color(0xFF4B3F72),
        unselectedItemColor: Colors.grey,
        elevation: 8,
        type: BottomNavigationBarType.fixed,
        currentIndex: 0, // default selected index
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.dashboard),
            label: "Teachers Dashboard",
          ),
        ],
        onTap: (index) {
          if (index == 0) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => StemPage(username: '',),
              ),
            );
          } else if (index == 1) {
            // Navigate to Teachers Dashboard
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TeachersDashboardPage(),
              ),
            );
          }
        },
      ),
    );
  }
}
