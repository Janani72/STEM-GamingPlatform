import 'dart:async';
import 'package:flutter/material.dart';

class Question {
  String question;
  List<String> options;
  String answer;
  Question({required this.question, required this.options, required this.answer});
}

class TreasureHuntScreen extends StatefulWidget {
  @override
  _TreasureHuntScreenState createState() => _TreasureHuntScreenState();
}

class _TreasureHuntScreenState extends State<TreasureHuntScreen> {
  final List<Question> questions = [
    Question(
        question: 'Ohm\'s Law formula?',
        options: ['V=IR', 'P=VI', 'E=MC2', 'F=ma'],
        answer: 'V=IR'),
    Question(
        question: 'Unit of Electric Current?',
        options: ['Volt', 'Ampere', 'Ohm', 'Watt'],
        answer: 'Ampere'),
    Question(
        question: 'Full form of PCB?',
        options: ['Printed Circuit Board', 'Primary Control Board', 'Power Circuit Block', 'Process Control Board'],
        answer: 'Printed Circuit Board'),
    Question(
        question: 'What is Boolean Algebra used in?',
        options: ['Digital Logic', 'Analog Circuit', 'Fluid Mechanics', 'Thermodynamics'],
        answer: 'Digital Logic'),
    Question(
        question: 'Unit of Frequency?',
        options: ['Hertz', 'Newton', 'Pascal', 'Tesla'],
        answer: 'Hertz'),
    Question(
        question: 'Ohm is a unit of?',
        options: ['Resistance', 'Voltage', 'Current', 'Power'],
        answer: 'Resistance'),
  ];

  late List<bool> treasureRevealed;
  int questionIndex = 0;
  int score = 0;

  @override
  void initState() {
    super.initState();
    treasureRevealed = List.generate(16, (_) => false); // 4x4 grid
  }

  void _askQuestion(int treasureIndex) {
    if (questionIndex >= questions.length) {
      _showGameOver();
      return;
    }

    Question q = questions[questionIndex];

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Center(child: Text('Question ${questionIndex + 1}')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(q.question, textAlign: TextAlign.center),
            SizedBox(height: 12),
            ...q.options.map((option) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 4.0),
                child: ElevatedButton(
                  onPressed: () {
                    if (option == q.answer) {
                      setState(() {
                        treasureRevealed[treasureIndex] = true;
                        score++;
                        questionIndex++;
                      });
                    } else {
                      setState(() {
                        questionIndex++;
                      });
                    }
                    Navigator.pop(context);
                    if (questionIndex >= questions.length || score == treasureRevealed.length) {
                      _showGameOver();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    minimumSize: Size(double.infinity, 40),
                  ),
                  child: Text(option),
                ),
              );
            }).toList(),
          ],
        ),
      ),
    );
  }

  void _showGameOver() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Center(
          child: Column(
            children: [
              Icon(Icons.emoji_events, color: Colors.amber, size: 48), // Trophy icon
              SizedBox(height: 8),
              Text('Game Over!', style: TextStyle(fontSize: 22)),
            ],
          ),
        ),
        content: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.celebration, color: Colors.orangeAccent, size: 48), // Celebration icon
              SizedBox(height: 12),
              Text(
                'Treasures Found: $score/${treasureRevealed.length}',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18),
              ),
            ],
          ),
        ),
        actions: [
          Center(
            child: TextButton.icon(
              icon: Icon(Icons.restart_alt, color: Colors.blueAccent),
              label: Text('Restart', style: TextStyle(color: Colors.blueAccent)),
              onPressed: () {
                setState(() {
                  score = 0;
                  questionIndex = 0;
                  treasureRevealed = List.generate(16, (_) => false);
                });
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Engineering Treasure Hunt - MCQ"),
        backgroundColor: const Color(0xFF4B3F72),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(
            color: Color(0xFF4B3F72),
            fontWeight: FontWeight.bold,
            fontSize: 20),
        elevation: 1,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: GridView.builder(
          itemCount: treasureRevealed.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 4, crossAxisSpacing: 8, mainAxisSpacing: 8),
          itemBuilder: (context, index) {
            return GestureDetector(
              onTap: () {
                if (!treasureRevealed[index]) _askQuestion(index);
              },
              child: Container(
                decoration: BoxDecoration(
                  color: treasureRevealed[index] ? Colors.orangeAccent : Colors.grey[700],
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.black),
                ),
                child: Center(
                  child: treasureRevealed[index]
                      ? Icon(Icons.celebration, color: Colors.yellowAccent, size: 36)
                      : Icon(Icons.lock, color: Colors.white, size: 32),
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
