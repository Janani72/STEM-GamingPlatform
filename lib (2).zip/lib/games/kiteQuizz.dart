
import 'package:flutter/material.dart';

class KiteQuizHome extends StatefulWidget {
  const KiteQuizHome({super.key});

  @override
  State<KiteQuizHome> createState() => _KiteQuizHomeState();
}

class _KiteQuizHomeState extends State<KiteQuizHome>
    with SingleTickerProviderStateMixin {
  // Questions (10) suitable for ages 6-12. Offline.
  final List<Question> _questions = [
    Question(
      text: 'What is the boiling point of water at sea level?',
      options: ['100°C', '0°C', '50°C', '212°C'],
      correctIndex: 0,
    ),
    Question(
      text: 'Which planet is known as the Red Planet?',
      options: ['Earth', 'Mars', 'Jupiter', 'Venus'],
      correctIndex: 1,
    ),
    Question(
      text: 'What do plants take in to make food (photosynthesis)?',
      options: ['Carbon dioxide', 'Oxygen', 'Nitrogen', 'Helium'],
      correctIndex: 0,
    ),
    Question(
      text: 'Which part of the body pumps blood?',
      options: ['Lungs', 'Brain', 'Heart', 'Stomach'],
      correctIndex: 2,
    ),
    Question(
      text: 'What gas do we breathe out?',
      options: ['Oxygen', 'Carbon dioxide', 'Hydrogen', 'Nitrogen'],
      correctIndex: 1,
    ),
    Question(
      text: 'Which force pulls objects toward Earth?',
      options: ['Magnetism', 'Gravity', 'Friction', 'Electricity'],
      correctIndex: 1,
    ),
    Question(
      text: 'Which material is a good conductor of electricity?',
      options: ['Wood', 'Plastic', 'Copper', 'Rubber'],
      correctIndex: 2,
    ),
    Question(
      text: 'Water turns into ice at which temperature?',
      options: ['0°C', '100°C', '-10°C', '50°C'],
      correctIndex: 0,
    ),
    Question(
      text: 'Which of these is not a mammal?',
      options: ['Whale', 'Shark', 'Bat', 'Human'],
      correctIndex: 1,
    ),
    Question(
      text: 'The Sun is mostly made of which element?',
      options: ['Iron', 'Hydrogen', 'Oxygen', 'Gold'],
      correctIndex: 1,
    ),
  ];

  int _currentQ = 0;
  int _score = 0;
  double _kiteTopPercent = 0.5; // 0 = top, 1 = bottom
  bool _showAnswerFeedback = false;
  String _feedbackText = '';

  // animation for smooth kite motion
  late final AnimationController _animController;
  late Animation<double> _kiteAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _kiteAnim = Tween<double>(begin: _kiteTopPercent, end: _kiteTopPercent)
        .animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut))
      ..addListener(() {
        setState(() {});
      });
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  void _answer(int chosen) {
    final q = _questions[_currentQ];
    bool correct = chosen == q.correctIndex;
    setState(() {
      _showAnswerFeedback = true;
      if (correct) {
        _score += 1;
        _feedbackText = 'Correct!';
        _moveKite(up: true);
      } else {
        _feedbackText = 'Wrong!';
        _moveKite(up: false);
      }
    });

    // wait a bit then go next question
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        _showAnswerFeedback = false;
        _currentQ = (_currentQ + 1) % _questions.length;
        // optional: you may restart when all asked
      });
    });
  }

  void _moveKite({required bool up}) {
    // Adjust target position a bit based on correctness
    // keep inside bounds between 0.05 and 0.85
    double change = up ? -0.12 : 0.12;
    double target = (_kiteAnim.value + change).clamp(0.05, 0.85);
    _kiteAnim = Tween<double>(begin: _kiteAnim.value, end: target)
        .animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));
    _animController.forward(from: 0);
  }

  void _restart() {
    setState(() {
      _currentQ = 0;
      _score = 0;
      _kiteAnim = Tween<double>(begin: 0.5, end: 0.5).animate(_animController);
      _animController.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    // kite vertical position in pixels
    double kiteTop = (_kiteAnim.value) * (size.height * 0.45) + 40;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Quiz - Science"),
        backgroundColor: const Color(0xFF4B3F72),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(
            color: Color(0xFF4B3F72),
            fontWeight: FontWeight.bold,
            fontSize: 20),
        elevation: 1,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Center(child: Text('Score: $_score')),
          )
        ],
      ),
      body: Stack(
        children: [
          // sky background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF81D4FA), Color(0xFFE1F5FE)],
              ),
            ),
          ),

          // sun
          Positioned(
            top: 20,
            right: 20,
            child: Container(
              width: 70,
              height: 70,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.yellow,
              ),
            ),
          ),

          // kite (animated)
          AnimatedPositioned(
            duration: const Duration(milliseconds: 600),
            top: kiteTop,
            left: size.width * 0.55,
            child: SizedBox(
              width: 120,
              height: 120,
              child: CustomPaint(
                painter: KitePainter(),
              ),
            ),
          ),

          // string from kid to kite
          Positioned.fill(
            child: CustomPaint(
              painter: StringPainter(kiteX: size.width * 0.55 + 60, kiteY: kiteTop + 40),
            ),
          ),

          // kid at bottom-left
          Positioned(
            left: 20,
            bottom: 20,
            child: SizedBox(
              width: 120,
              height: 160,
              child: CustomPaint(
                painter: KidPainter(),
              ),
            ),
          ),

          // question area at bottom-right
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              padding: const EdgeInsets.all(12),
              margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.9),
                borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 6)],
              ),
              height: 250,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Q${_currentQ + 1}. ${_questions[_currentQ].text}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Expanded(
                    child: GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        mainAxisSpacing: 8,
                        crossAxisSpacing: 8,
                        childAspectRatio: 4,
                      ),
                      itemCount: _questions[_currentQ].options.length,
                      itemBuilder: (context, index) {
                        return ElevatedButton(
                          onPressed: () => _answer(index),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[400],
                          ),
                          child: Text(_questions[_currentQ].options[index]),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (_showAnswerFeedback)
                        Text(
                          _feedbackText,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: _feedbackText == 'Correct!' ? Colors.green : Colors.red,
                          ),
                        )
                      else
                        const SizedBox(width: 1),
                      TextButton(
                        onPressed: _restart,
                        child: const Text('Restart'),
                      )
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class Question {
  final String text;
  final List<String> options;
  final int correctIndex;

  Question({required this.text, required this.options, required this.correctIndex});
}

// Simple kite painter
class KitePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..style = PaintingStyle.fill;

    // diamond kite
    paint.color = Colors.redAccent;
    final path = Path();
    path.moveTo(size.width / 2, 0);
    path.lineTo(size.width, size.height / 2);
    path.lineTo(size.width / 2, size.height);
    path.lineTo(0, size.height / 2);
    path.close();
    canvas.drawPath(path, paint);

    // cross sticks
    final stick = Paint()
      ..color = Colors.brown
      ..strokeWidth = 3;
    canvas.drawLine(Offset(size.width / 2, 0), Offset(size.width / 2, size.height), stick);
    canvas.drawLine(Offset(0, size.height / 2), Offset(size.width, size.height / 2), stick);

    // tail
    final tail = Paint()..color = Colors.black;
    final tailPath = Path();
    tailPath.moveTo(size.width / 2, size.height);
    tailPath.lineTo(size.width / 2, size.height + 30);
    canvas.drawPath(tailPath, tail);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// String painter draws curved line from kid to kite
class StringPainter extends CustomPainter {
  final double kiteX;
  final double kiteY;

  StringPainter({required this.kiteX, required this.kiteY});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black
      ..strokeWidth = 1.8
      ..style = PaintingStyle.stroke;

    // kid position (bottom-left)
    final start = Offset(20 + 60, size.height - 20 - 20); // approximate hand position
    final kite = Offset(kiteX, kiteY);

    final path = Path();
    path.moveTo(start.dx, start.dy);
    // a simple quadratic bezier curve for string
    path.quadraticBezierTo((start.dx + kite.dx) / 2, (start.dy + kite.dy) / 2 - 40, kite.dx, kite.dy);
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant StringPainter oldDelegate) => oldDelegate.kiteX != kiteX || oldDelegate.kiteY != kiteY;
}

// Kid painter - simple shape for a child holding the kite
class KidPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.brown[300]!;

    // head
    canvas.drawCircle(Offset(size.width / 2, 24), 18, paint);

    // body
    final bodyPaint = Paint()..color = Colors.green[700]!;
    canvas.drawRect(Rect.fromLTWH(size.width / 2 - 18, 44, 36, 50), bodyPaint);

    // legs
    final leg = Paint()..color = Colors.blue[900]!;
    canvas.drawRect(Rect.fromLTWH(size.width / 2 - 18, 94, 12, 28), leg);
    canvas.drawRect(Rect.fromLTWH(size.width / 2 + 6, 94, 12, 28), leg);

    // arm (right) holding string - small rectangle
    final arm = Paint()..color = Colors.brown[300]!;
    canvas.drawRect(Rect.fromLTWH(size.width / 2 + 18, 56, 26, 8), arm);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
