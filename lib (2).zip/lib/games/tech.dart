import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class CardModel {
  String content; // term or definition
  bool isFlipped;
  bool isMatched;
  CardModel({required this.content, this.isFlipped = false, this.isMatched = false});
}

class MemoryGameScreen extends StatefulWidget {
  @override
  _MemoryGameScreenState createState() => _MemoryGameScreenState();
}

class _MemoryGameScreenState extends State<MemoryGameScreen> {
  List<CardModel> cards = [];
  CardModel? firstCard;
  CardModel? secondCard;
  bool allowFlip = true;
  int score = 0;
  int timeLeft = 60;
  late Timer timer;

  final Map<String, String> techPairs = {
    // Easy
    'CPU': 'Central Processing Unit',
    'RAM': 'Random Access Memory',
    'HTTP': 'HyperText Transfer Protocol',
    'GPU': 'Graphics Processing Unit',
    'IoT': 'Internet of Things',
    'DNS': 'Domain Name System',
    'API': 'Application Programming Interface',


    // // Medium
    // 'DNS': 'Domain Name System',
    // 'API': 'Application Programming Interface',
    // 'SSL': 'Secure Sockets Layer',
    // 'SQL': 'Structured Query Language',
    // 'OS': 'Operating System',
    //
    // // Hard
    // 'Blockchain': 'Distributed Ledger Technology',
    // 'Kubernetes': 'Container Orchestration',
    // 'OAuth': 'Open Authorization Protocol',
    // 'Virtualization': 'Creating Virtual Versions of Resources',
    // 'DNSSEC': 'Domain Name System Security Extensions',
  };


  @override
  void initState() {
    super.initState();
    _generateCards();
    timer = Timer.periodic(Duration(seconds: 1), (t) {
      if (timeLeft > 0) {
        setState(() {
          timeLeft--;
        });
      } else {
        _showGameOver();
      }
    });
  }

  void _generateCards() {
    cards.clear();
    List<String> tempList = [];
    techPairs.forEach((term, def) {
      tempList.add(term);
      tempList.add(def);
    });
    tempList.shuffle(Random());
    cards = tempList.map((c) => CardModel(content: c)).toList();
  }

  void _flipCard(int index) {
    if (!allowFlip || cards[index].isFlipped || cards[index].isMatched) return;

    setState(() {
      cards[index].isFlipped = true;
      if (firstCard == null) {
        firstCard = cards[index];
      } else {
        secondCard = cards[index];
        allowFlip = false;

        Future.delayed(Duration(seconds: 1), () {
          setState(() {
            if (_isMatch(firstCard!, secondCard!)) {
              firstCard!.isMatched = true;
              secondCard!.isMatched = true;
              score += 10;
              if (_checkAllMatched()) _showGameOver();
            } else {
              firstCard!.isFlipped = false;
              secondCard!.isFlipped = false;
            }
            firstCard = null;
            secondCard = null;
            allowFlip = true;
          });
        });
      }
    });
  }

  bool _isMatch(CardModel c1, CardModel c2) {
    return techPairs[c1.content] == c2.content || techPairs[c2.content] == c1.content;
  }

  bool _checkAllMatched() {
    return cards.every((c) => c.isMatched);
  }

  void _showGameOver() {
    timer.cancel();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        title: Text('Game Over!'),
        content: Text('Your Score: $score'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                score = 0;
                timeLeft = 60;
                firstCard = null;
                secondCard = null;
                allowFlip = true;
                _generateCards();
                timer = Timer.periodic(Duration(seconds: 1), (t) {
                  if (timeLeft > 0) {
                    setState(() {
                      timeLeft--;
                    });
                  } else {
                    _showGameOver();
                  }
                });
              });
              Navigator.pop(context);
            },
            child: Text('Restart'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Quiz - Science"),
        backgroundColor: const Color(0xFF4B3F72),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(
            color: Color(0xFF4B3F72),
            fontWeight: FontWeight.bold,
            fontSize: 20),
        elevation: 1,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Text('Score: $score', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Text('Time Left: $timeLeft', style: TextStyle(fontSize: 20)),
          SizedBox(height: 10),
          Expanded(
            child: GridView.builder(
              padding: EdgeInsets.all(10),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10),
              itemCount: cards.length,
              itemBuilder: (context, index) {
                return GestureDetector(
                  onTap: () => _flipCard(index),
                  child: Container(
                    decoration: BoxDecoration(
                      color: cards[index].isFlipped || cards[index].isMatched
                          ? Colors.orangeAccent
                          : Colors.blueAccent,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Center(
                      child: Text(
                        cards[index].isFlipped || cards[index].isMatched
                            ? cards[index].content
                            : '',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
