import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class Bubble {
  double x; // horizontal position
  double y; // vertical position
  int value;
  Bubble({required this.x, required this.y, required this.value});
}

class BubbleGameScreen extends StatefulWidget {
  @override
  _BubbleGameScreenState createState() => _BubbleGameScreenState();
}

class _BubbleGameScreenState extends State<BubbleGameScreen> {
  final Random _random = Random();
  final double bubbleSize = 50;
  int score = 0;
  bool gameOver = false;

  List<Bubble> bubbles = [];
  late Timer timer;
  late int currentAnswer;
  late String currentQuestion;
  bool initialized = false;

  final List<Map<String, int>> questions = [
    {'5 + 3': 8},
    {'6 - 2': 4},
    {'2 × 3': 6},
    {'12 ÷ 4': 3},
    {'7 + 2': 9},
  ];

  int questionIndex = 0;

  @override
  void initState() {
    super.initState();
    _setQuestion();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!initialized) {
      _generateBubbles();
      timer = Timer.periodic(Duration(milliseconds: 50), _updateBubbles);
      initialized = true;
    }
  }

  void _setQuestion() {
    if (questionIndex >= questions.length) questionIndex = 0;
    currentQuestion = questions[questionIndex].keys.first;
    currentAnswer = questions[questionIndex][currentQuestion]!;
  }

  void _generateBubbles() {
    bubbles.clear();
    for (int i = 0; i < 5; i++) {
      bubbles.add(Bubble(
        x: _random.nextDouble() * (MediaQuery.of(context).size.width - bubbleSize),
        y: _random.nextDouble() * -300, // start off-screen
        value: _random.nextInt(12) + 1,
      ));
    }
    // Ensure at least one correct answer
    bubbles[_random.nextInt(bubbles.length)].value = currentAnswer;
  }

  void _updateBubbles(Timer t) {
    if (gameOver) return;
    setState(() {
      for (var bubble in bubbles) {
        bubble.y += 2; // speed of falling
      }

      for (var bubble in bubbles) {
        if (bubble.y + bubbleSize >= MediaQuery.of(context).size.height - 50) {
          if (bubble.value != currentAnswer) {
            gameOver = true;
            timer.cancel();
            _showGameOver();
            break;
          }
        }
      }
    });
  }

  void _tapBubble(Bubble bubble) {
    if (bubble.value == currentAnswer) {
      setState(() {
        score += 10;
        questionIndex++;

        if (questionIndex >= questions.length) {
          // All questions answered → game finished
          gameOver = true;
          timer.cancel();
          _showGameOver();
        } else {
          _setQuestion();
          _generateBubbles();
        }
      });
    } else {
      setState(() {
        score -= 2; // optional penalty
      });
    }
  }


  void _showGameOver() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('Game Over!'),
        content: Text('Your Score: $score'),
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                score = 0;
                bubbles.clear();
                gameOver = false;
                questionIndex = 0;
                _setQuestion();
                _generateBubbles();
                timer = Timer.periodic(Duration(milliseconds: 50), _updateBubbles);
                Navigator.pop(context);
              });
            },
            child: Text('Restart'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Mathematics"),
        backgroundColor: const Color(0xFF4B3F72),
        iconTheme: const IconThemeData(color: Colors.white),
        titleTextStyle: const TextStyle(
            color: Color(0xFF4B3F72),
            fontWeight: FontWeight.bold,
            fontSize: 20),
        elevation: 1,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12.0),
            child: Center(child: Text('Score: $score')),
          )
        ],
      ),
      body: Stack(
        children: [
          Positioned(
            top: 60,
            left: 20,
            child: Text(
              'Question: $currentQuestion = ?',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
            ),
          ),
          ...bubbles.map((bubble) {
            return Positioned(
              left: bubble.x,
              top: bubble.y,
              child: GestureDetector(
                onTap: () => _tapBubble(bubble),
                child: CircleAvatar(
                  radius: bubbleSize / 2,
                  backgroundColor: Colors.orangeAccent,
                  child: Text(
                    '${bubble.value}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
              ),
            );
          }).toList(),
        ],
      ),
    );
  }
}
